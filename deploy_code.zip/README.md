# AquaFish Store - Aquatic Fish E-Commerce Platform

A comprehensive Django-based e-commerce website for selling aquatic fishes, featuring role-based access control for customers, staff, and administrators.

## Features

### 🌊 Aquatic Theme
- Beautiful underwater/aquatic-themed UI with gradient backgrounds
- Modern, responsive design with smooth animations
- Fish-themed icons and visual elements throughout

### 👥 Three User Modules

#### 1. Customer Module
- Browse and view fishes by category and breed
- Advanced search and filter functionality
- Add items to shopping cart
- Checkout and place orders
- View order history and details
- Profile management

#### 2. Staff Module
- View all fishes with search and filter
- Add new categories for fishes
- Add breeds within categories
- Add new fishes with images, pricing, and stock management
- Edit and delete fishes, categories, and breeds
- Dashboard with statistics

#### 3. Admin Module
- **Staff Management**: Add and remove staff members
- **Category & Fish Management**: Full CRUD operations
- **Order Monitoring**: View all orders with filtering options
- **User Management**: View user details and block/unblock users
- **Data Export**: Export order data to Excel/spreadsheet format
- **Advanced Dashboard**: Revenue tracking and statistics

### 🔐 Authentication System
- Email OTP verification for user registration
- Single login page with role-based authentication
- Forgot password functionality (for customers and staff)
- Secure password reset via OTP

### 👤 Profile Management
- Each role has its own profile page
- Users can edit their personal information
- Profile picture upload support

## Installation

### Prerequisites
- Python 3.8 or higher
- pip (Python package manager)

### Setup Steps

1. **Clone or navigate to the project directory**
   ```bash
   cd CURSOR
   ```

2. **Create a virtual environment (recommended)**
   ```bash
   python -m venv venv
   ```

3. **Activate the virtual environment**
   - On Windows:
     ```bash
     venv\Scripts\activate
     ```
   - On macOS/Linux:
     ```bash
     source venv/bin/activate
     ```

4. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

5. **Run migrations**
   ```bash
   python manage.py makemigrations
   python manage.py migrate
   ```

6. **Create a superuser (admin account)**
   ```bash
   python manage.py createsuperuser
   ```
   Follow the prompts to create an admin user. This user will have admin role by default.

7. **Collect static files**
   ```bash
   python manage.py collectstatic
   ```

8. **Run the development server**
   ```bash
   python manage.py runserver
   ```

9. **Access the application**
   - Open your browser and go to: `http://127.0.0.1:8000/`
   - Admin panel: `http://127.0.0.1:8000/admin/`

## Configuration

### Email Settings (for OTP)
By default, the application uses console email backend for development. To enable actual email sending, update `aquafish_store/settings.py`:

```python
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 587
EMAIL_USE_TLS = True
EMAIL_HOST_USER = 'your-email@gmail.com'
EMAIL_HOST_PASSWORD = 'your-password'
DEFAULT_FROM_EMAIL = 'your-email@gmail.com'
```

### Media Files
Make sure to create a `media` directory in the project root for uploaded images:
```bash
mkdir media
```

## Project Structure

```
CURSOR/
├── aquafish_store/          # Main Django project settings
│   ├── settings.py          # Project configuration
│   ├── urls.py              # Main URL routing
│   └── wsgi.py              # WSGI configuration
├── store/                   # Main application
│   ├── models.py            # Database models
│   ├── views.py             # View functions
│   ├── urls.py              # App URL routing
│   ├── forms.py             # Form definitions
│   └── templates/           # HTML templates
│       ├── store/           # Base templates
│       ├── customer/        # Customer module templates
│       ├── staff/           # Staff module templates
│       └── admin/           # Admin module templates
├── static/                  # Static files (CSS, JS, images)
│   └── css/
│       └── style.css        # Aquatic theme styles
├── media/                   # User-uploaded files (created automatically)
├── manage.py                # Django management script
├── requirements.txt         # Python dependencies
└── README.md               # This file
```

## Usage

### Creating an Admin User
1. Use the superuser created during setup
2. Or create one via Django admin panel or manage.py

### Creating Staff Users
1. Login as admin
2. Navigate to "Staff" in the admin dashboard
3. Click "Add Staff"
4. Fill in the registration form

### Customer Registration
1. Visit the home page
2. Click "Register"
3. Fill in registration details
4. Check email for OTP
5. Enter OTP to verify email
6. Login with credentials

## Technologies Used

- **Django 4.2.7**: Web framework
- **Bootstrap 5**: Frontend framework
- **Font Awesome**: Icons
- **Pillow**: Image processing
- **openpyxl**: Excel export functionality
- **pandas**: Data manipulation (for export features)
- **django-crispy-forms**: Enhanced form rendering

## Key Features Implementation

### Role-Based Access Control
- Custom user model with role field
- Decorators for access control (`@user_passes_test`)
- Different dashboards and views per role

### Email OTP System
- OTP generation and validation
- Email sending via Django's email backend
- OTP expiration (5 minutes)

### Cart System
- Session-based cart (linked to authenticated users)
- Quantity management
- Real-time total calculation

### Order Management
- Order number generation
- Order status tracking
- Order history for customers
- Admin order monitoring

### Excel Export
- Filter orders by status and date range
- Export to .xlsx format with formatting
- Download via browser

## Security Notes

- Change `SECRET_KEY` in production
- Set `DEBUG = False` in production
- Configure proper email backend for production
- Use secure database (PostgreSQL recommended)
- Set up proper static file serving
- Use HTTPS in production

## License

This project is created for educational/commercial purposes.

## Support

For issues or questions, please refer to the Django documentation or create an issue in the repository.

---

**Enjoy your aquatic fish store! 🐠🌊**

#   a q u a t i c s  
 