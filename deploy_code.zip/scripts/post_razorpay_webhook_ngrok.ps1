Write-Host "This helper was removed. See tools/ for webhook test instructions." -ForegroundColor Yellow
